package project.patientTreatment;

public record Disease(Long id, String name) {
}
