
insert into PATIENT(id, first_name, last_name, mid_name, age) values (99, 'derek', 'hopes', '', 35);


